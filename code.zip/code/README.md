# Analysis Code: Beyond Node Degree

Reproducible pipeline for "Beyond Node Degree: Edge-Weight Concentration as a
Lightweight, Identity-Robust Structural Signature for Network Flood Detection"

## Requirements
```
pip install pandas numpy networkx scikit-learn scipy matplotlib pyarrow
```

## Data
Download `Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv` (GeneratedLabelledFlows
release, which retains Source IP/Destination IP) from the CICIDS2017 dataset:
https://www.unb.ca/cic/datasets/ids-2017.html

## Pipeline order
1. `graph_features.py` — builds time-windowed host-communication graphs and
   window-level structural features (node-degree and edge-weight families).
   Run directly: `python3 graph_features.py <path_to_csv> <window_seconds>`
2. `feature_engineering.py` — builds the aligned per-flow baseline (CICFlowMeter)
   and graph-context feature matrices used for classification.
3. `run_baseline_comparison.py` — 5-fold CV comparison of baseline vs. graph-context
   vs. combined features (Logistic Regression, Random Forest), with Wilcoxon
   significance testing.
4. `run_full.py` — same comparison intended for the full (non-subsampled) dataset.

Outputs (window_features.csv, baseline_comparison.csv, ablation results,
sensitivity tables) are written to a `results/` directory relative to the
working directory.
