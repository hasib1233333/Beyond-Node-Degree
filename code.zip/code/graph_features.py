"""
graph_features.py

Builds time-windowed directed host-communication graphs from CICIDS2017-style
labeled flow records (Source IP, Destination IP, Timestamp, Label, ...) and
extracts a set of lightweight, interpretable graph-structural features per
window. These features are the basis for comparing structural signatures
across attack archetypes (flood / fan-in, reconnaissance / fan-out,
beaconing, slow multi-host infiltration) without relying on deep graph
neural networks.

Author: research pipeline for Discover Networks submission.
"""

import pandas as pd
import numpy as np
import networkx as nx
from collections import Counter


def load_flows(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df.columns = [c.strip() for c in df.columns]
    df['Timestamp'] = pd.to_datetime(df['Timestamp'], format='mixed', dayfirst=False, errors='coerce')
    n_bad = df['Timestamp'].isna().sum()
    if n_bad:
        df = df.dropna(subset=['Timestamp'])
    df = df.sort_values('Timestamp').reset_index(drop=True)
    df['Label'] = df['Label'].astype(str).str.strip()
    return df


def _shannon_entropy(counts):
    counts = np.array(counts, dtype=float)
    counts = counts[counts > 0]
    if counts.sum() == 0:
        return 0.0
    p = counts / counts.sum()
    return float(-(p * np.log2(p)).sum())


def _gini(counts):
    x = np.sort(np.array(counts, dtype=float))
    n = len(x)
    if n == 0 or x.sum() == 0:
        return 0.0
    cum = np.cumsum(x)
    return float((n + 1 - 2 * (cum.sum() / cum[-1])) / n * -1)


def build_window_graph(window_df: pd.DataFrame) -> nx.MultiDiGraph:
    G = nx.MultiDiGraph()
    for _, row in window_df.iterrows():
        src, dst = row['Source IP'], row['Destination IP']
        G.add_edge(src, dst,
                   dport=row.get('Destination Port', np.nan),
                   proto=row.get('Protocol', np.nan),
                   label=row['Label'])
    return G


def window_structural_features(G: nx.MultiDiGraph, prev_edge_set: set, window_df: pd.DataFrame) -> dict:
    """Compute a lightweight, interpretable structural feature vector for one
    time-windowed host-communication graph."""
    feats = {}

    n_nodes = G.number_of_nodes()
    n_edges_multi = G.number_of_edges()
    feats['n_nodes'] = n_nodes
    feats['n_flows'] = len(window_df)

    # collapse multigraph to simple weighted digraph for structural metrics
    SG = nx.DiGraph()
    for u, v, data in G.edges(data=True):
        if SG.has_edge(u, v):
            SG[u][v]['weight'] += 1
        else:
            SG.add_edge(u, v, weight=1)
    feats['n_unique_edges'] = SG.number_of_edges()
    feats['edge_density'] = nx.density(SG) if n_nodes > 1 else 0.0

    # --- edge-weight (flow-multiplicity) features ---
    # Node-degree features assume attacker identity is visible as distinct
    # graph neighbors. Under NAT/perimeter collapse (many real attackers
    # sharing one gateway IP, or a single attacker flooding one victim),
    # the signal instead concentrates onto a SMALL NUMBER of HEAVILY
    # REPEATED edges rather than many distinct neighbors. These features
    # capture that "identity-collapsed" attack signature.
    weights = [d['weight'] for _, _, d in SG.edges(data=True)]
    feats['max_edge_weight'] = max(weights) if weights else 0
    feats['mean_edge_weight'] = float(np.mean(weights)) if weights else 0.0
    feats['edge_weight_entropy'] = _shannon_entropy(weights)
    feats['top1_edgeweight_share'] = (max(weights) / sum(weights)) if weights else 0.0
    # fraction of ALL flows in this window carried by the single heaviest edge
    feats['top1_edge_flow_share'] = (max(weights) / len(window_df)) if len(window_df) else 0.0

    in_degs = [d for _, d in SG.in_degree()]
    out_degs = [d for _, d in SG.out_degree()]
    feats['max_in_degree'] = max(in_degs) if in_degs else 0
    feats['max_out_degree'] = max(out_degs) if out_degs else 0
    feats['mean_in_degree'] = float(np.mean(in_degs)) if in_degs else 0.0
    feats['mean_out_degree'] = float(np.mean(out_degs)) if out_degs else 0.0
    feats['in_degree_entropy'] = _shannon_entropy(in_degs)
    feats['out_degree_entropy'] = _shannon_entropy(out_degs)
    feats['in_degree_gini'] = _gini(in_degs)
    feats['out_degree_gini'] = _gini(out_degs)

    # fan-in / fan-out concentration: share of edges pointing at the single
    # highest in-degree node (captures DDoS-style flood concentration)
    if in_degs:
        feats['top1_indegree_share'] = max(in_degs) / max(sum(in_degs), 1)
    else:
        feats['top1_indegree_share'] = 0.0
    if out_degs:
        feats['top1_outdegree_share'] = max(out_degs) / max(sum(out_degs), 1)
    else:
        feats['top1_outdegree_share'] = 0.0

    # weakly connected components
    if n_nodes > 0:
        wccs = list(nx.weakly_connected_components(SG))
        wcc_sizes = sorted([len(c) for c in wccs], reverse=True)
        feats['n_components'] = len(wccs)
        feats['largest_component_frac'] = wcc_sizes[0] / n_nodes if wcc_sizes else 0.0
    else:
        feats['n_components'] = 0
        feats['largest_component_frac'] = 0.0

    # destination-port diversity per source (reconnaissance / port-scan signal)
    port_div = window_df.groupby('Source IP')['Destination Port'].nunique()
    feats['max_dstport_diversity'] = int(port_div.max()) if len(port_div) else 0
    feats['mean_dstport_diversity'] = float(port_div.mean()) if len(port_div) else 0.0

    # destination diversity per source (fan-out / scanning across hosts)
    dst_div = window_df.groupby('Source IP')['Destination IP'].nunique()
    feats['max_dsthost_diversity'] = int(dst_div.max()) if len(dst_div) else 0

    # structural novelty: fraction of this window's edges not seen in the
    # previous window (temporal structural drift)
    curr_edges = set(SG.edges())
    if prev_edge_set is not None and len(curr_edges) > 0:
        new_edges = curr_edges - prev_edge_set
        feats['new_edge_ratio'] = len(new_edges) / len(curr_edges)
    else:
        feats['new_edge_ratio'] = np.nan

    # clustering (on undirected projection; cheap, interpretable)
    try:
        feats['avg_clustering'] = nx.average_clustering(SG.to_undirected())
    except Exception:
        feats['avg_clustering'] = 0.0

    # label summary for this window
    label_counts = Counter(window_df['Label'])
    feats['n_benign'] = label_counts.get('BENIGN', 0)
    feats['n_attack'] = len(window_df) - feats['n_benign']
    feats['attack_frac'] = feats['n_attack'] / len(window_df) if len(window_df) else 0.0
    dominant_attack = None
    if feats['n_attack'] > 0:
        attack_labels = {k: v for k, v in label_counts.items() if k != 'BENIGN'}
        dominant_attack = max(attack_labels, key=attack_labels.get)
    feats['dominant_label'] = dominant_attack if dominant_attack else 'BENIGN'

    return feats, curr_edges


def build_windowed_features(df: pd.DataFrame, window_seconds: int = 60) -> pd.DataFrame:
    """Slide a fixed-size time window across the flow log and compute one
    structural feature row per window."""
    t0 = df['Timestamp'].min()
    df = df.copy()
    df['window_id'] = ((df['Timestamp'] - t0).dt.total_seconds() // window_seconds).astype(int)

    rows = []
    prev_edges = None
    for wid, wdf in df.groupby('window_id'):
        if len(wdf) == 0:
            continue
        G = build_window_graph(wdf)
        feats, curr_edges = window_structural_features(G, prev_edges, wdf)
        feats['window_id'] = wid
        feats['window_start'] = t0 + pd.Timedelta(seconds=int(wid) * window_seconds)
        rows.append(feats)
        prev_edges = curr_edges

    return pd.DataFrame(rows).sort_values('window_id').reset_index(drop=True)


if __name__ == '__main__':
    import sys
    path = sys.argv[1] if len(sys.argv) > 1 else \
        "/mnt/user-data/uploads/Friday-WorkingHours-Afternoon-DDos_pcap_ISCX.csv"
    window_s = int(sys.argv[2]) if len(sys.argv) > 2 else 60

    df = load_flows(path)
    print(f"Loaded {len(df)} flows spanning {df['Timestamp'].min()} -> {df['Timestamp'].max()}")
    feat_df = build_windowed_features(df, window_seconds=window_s)
    out_path = "/home/claude/project/results/window_features.csv"
    feat_df.to_csv(out_path, index=False)
    print(f"Wrote {len(feat_df)} window rows to {out_path}")
    print(feat_df[['window_id', 'n_nodes', 'n_unique_edges', 'max_in_degree',
                    'in_degree_entropy', 'new_edge_ratio', 'attack_frac', 'dominant_label']].to_string())
