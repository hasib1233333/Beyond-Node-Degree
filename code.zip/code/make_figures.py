"""
make_figures.py

Regenerates the two data-driven figures used in the manuscript:
  - prelim_ddos_signal.png : node-degree vs. edge-weight signal comparison
    across time windows (Fig. 2 in the manuscript).
  - ablation_flowlevel.png : flow-level classification F1 by graph-context
    feature subset (Fig. 3 in the manuscript).
(Fig. 1, the NAT-collapse conceptual diagram, is native TikZ inside main.tex
and does not need to be regenerated from data.)
"""

import sys
import pandas as pd
import matplotlib.pyplot as plt

from graph_features import load_flows, build_windowed_features


def make_signal_figure(csv_path: str, out_path: str = "figures/prelim_ddos_signal.png"):
    df = load_flows(csv_path)
    feat = build_windowed_features(df, window_seconds=120)
    attack_mask = feat['dominant_label'] == 'DDoS'

    fig, axes = plt.subplots(3, 1, figsize=(11, 9), sharex=True)
    axes[0].plot(feat['window_id'], feat['max_in_degree'], color='#555555', marker='o', ms=3)
    axes[0].fill_between(feat['window_id'], 0, feat['max_in_degree'].max() * 1.1, where=attack_mask, color='red', alpha=0.12)
    axes[0].set_ylabel('max in-degree')
    axes[0].set_title('Node-degree feature: no separation during attack (shaded = DDoS-dominant window)')

    axes[1].plot(feat['window_id'], feat['max_edge_weight'], color='#1f77b4', marker='o', ms=3)
    axes[1].fill_between(feat['window_id'], 0, feat['max_edge_weight'].max() * 1.1, where=attack_mask, color='red', alpha=0.12)
    axes[1].set_ylabel('max edge weight\n(flows on single busiest pair)')
    axes[1].set_title('Edge-weight feature: clean separation')

    axes[2].plot(feat['window_id'], feat['edge_weight_entropy'], color='#2ca02c', marker='o', ms=3)
    axes[2].fill_between(feat['window_id'], 0, feat['edge_weight_entropy'].max() * 1.1, where=attack_mask, color='red', alpha=0.12)
    axes[2].set_ylabel('edge-weight entropy')
    axes[2].set_xlabel('time window (120s each)')
    axes[2].set_title('Edge-weight entropy collapses during attack')

    plt.tight_layout()
    plt.savefig(out_path, dpi=130)
    print(f"saved {out_path}")


def make_ablation_figure(ablation_csv: str = "results/ablation_flowlevel.csv",
                          out_path: str = "figures/ablation_flowlevel.png"):
    abl = pd.read_csv(ablation_csv).sort_values('f1_mean')
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.barh(abl['feature_subset'], abl['f1_mean'], xerr=abl['f1_std'], capsize=3)
    ax.set_xlabel('F1 score (5-fold CV mean $\\pm$ std)')
    ax.set_xlim(0.75, 1.02)
    ax.set_title('Ablation: per-flow classification F1 by graph-context feature subset')
    for i, (v, d) in enumerate(zip(abl['f1_mean'], abl['n_dims'])):
        ax.text(v + 0.005, i, f'{v:.4f} (d={d})', va='center', fontsize=9)
    plt.tight_layout()
    plt.savefig(out_path, dpi=130)
    print(f"saved {out_path}")


if __name__ == '__main__':
    csv_path = sys.argv[1] if len(sys.argv) > 1 else \
        "/mnt/user-data/uploads/Friday-WorkingHours-Afternoon-DDos_pcap_ISCX.csv"
    make_signal_figure(csv_path)
    make_ablation_figure()
