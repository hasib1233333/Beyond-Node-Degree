"""
run_ablation.py

Ablation study: which individual structural feature drives the window-level
separation (Table: window-level ablation), and how do graph-context feature
subsets combine at the flow-classification level (Table: flow-level ablation,
Figure: ablation_flowlevel.png)?

Requires window_features.csv-equivalent generation via graph_features.py and
the parquet feature matrices produced by feature_engineering.py.
"""

import sys
import numpy as np
import pandas as pd
from scipy.stats import mannwhitneyu
from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import f1_score, roc_auc_score

from graph_features import load_flows, build_windowed_features


def window_level_ablation(csv_path: str, window_seconds: int = 60):
    df = load_flows(csv_path)
    feat = build_windowed_features(df, window_seconds=window_seconds)
    feat['is_attack_window'] = feat['attack_frac'] > 0.1

    candidates = ['max_edge_weight', 'edge_weight_entropy', 'top1_edgeweight_share',
                  'top1_edge_flow_share', 'mean_edge_weight', 'n_unique_edges',
                  'max_in_degree', 'max_out_degree', 'in_degree_entropy', 'new_edge_ratio',
                  'max_dstport_diversity', 'max_dsthost_diversity']
    rows = []
    for col in candidates:
        if col not in feat.columns:
            continue
        a = feat.loc[feat['is_attack_window'], col].dropna()
        b = feat.loc[~feat['is_attack_window'], col].dropna()
        if len(a) < 2 or len(b) < 2:
            continue
        stat, p = mannwhitneyu(a, b, alternative='two-sided')
        auc = stat / (len(a) * len(b))
        rows.append({'feature': col, 'p_value': p, 'separation_auc': max(auc, 1 - auc)})
    return pd.DataFrame(rows).sort_values('separation_auc', ascending=False)


def flow_level_ablation(ctx_parquet: str, labels_parquet: str, subsample_n: int = 40000, seed: int = 42):
    ctx = pd.read_parquet(ctx_parquet)
    y = pd.read_parquet(labels_parquet)['y']

    rng = np.random.RandomState(seed)
    idx_pos, idx_neg = y[y == 1].index.to_numpy(), y[y == 0].index.to_numpy()
    n_pos = int(subsample_n * (len(idx_pos) / len(y)))
    n_neg = subsample_n - n_pos
    sel = np.concatenate([rng.choice(idx_pos, n_pos, replace=False),
                           rng.choice(idx_neg, n_neg, replace=False)])
    ctx, y = ctx.loc[sel].reset_index(drop=True), y.loc[sel].reset_index(drop=True)

    subsets = {
        'top1_edge_flow_share only': ['pair_edge_weight_w'],
        'window_edge_weight_entropy only': ['window_edge_weight_entropy'],
        'window_top1_edge_share only': ['window_top1_edge_share'],
        'top-3 edge-weight features': ['pair_edge_weight_w', 'window_edge_weight_entropy', 'window_top1_edge_share'],
        'degree-only (src/dst degree)': ['src_out_degree_w', 'dst_in_degree_w'],
        'diversity-only': ['src_dstport_diversity_w', 'dst_srcip_diversity_w'],
        'all 10 graph-context features': list(ctx.columns),
    }
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=seed)
    rows = []
    for name, cols in subsets.items():
        X = ctx[cols]
        pipe = Pipeline([('impute', SimpleImputer(strategy='median')), ('scale', StandardScaler()),
                          ('clf', LogisticRegression(max_iter=2000, class_weight='balanced', random_state=seed))])
        f1s, aucs = [], []
        for tr, te in skf.split(X, y):
            pipe.fit(X.iloc[tr], y.iloc[tr])
            pred = pipe.predict(X.iloc[te])
            proba = pipe.predict_proba(X.iloc[te])[:, 1]
            f1s.append(f1_score(y.iloc[te], pred))
            aucs.append(roc_auc_score(y.iloc[te], proba))
        rows.append({'feature_subset': name, 'n_dims': len(cols),
                      'f1_mean': np.mean(f1s), 'f1_std': np.std(f1s), 'roc_auc_mean': np.mean(aucs)})
    return pd.DataFrame(rows)


if __name__ == '__main__':
    csv_path = sys.argv[1] if len(sys.argv) > 1 else \
        "/mnt/user-data/uploads/Friday-WorkingHours-Afternoon-DDos_pcap_ISCX.csv"

    win_abl = window_level_ablation(csv_path, window_seconds=60)
    win_abl.to_csv("results/ablation_single_feature.csv", index=False)
    print(win_abl.to_string(index=False))

    flow_abl = flow_level_ablation("data/graph_context_features.parquet", "data/labels.parquet")
    flow_abl.to_csv("results/ablation_flowlevel.csv", index=False)
    print(flow_abl.to_string(index=False))
