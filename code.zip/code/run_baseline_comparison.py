"""
run_baseline_comparison.py

Fair comparison of three feature conditions for per-flow BENIGN/attack
classification on the Friday-Afternoon-DDoS day:
  (A) baseline   - standard CICFlowMeter behavioral features only
  (B) graph      - lightweight graph-structural context features only
  (C) combined   - both

Stratified 5-fold CV, two model families (Logistic Regression, Random
Forest), Precision/Recall/F1/ROC-AUC/PR-AUC reported as mean +/- std across
folds, plus a paired Wilcoxon signed-rank test (combined vs baseline, on
per-fold F1) to check whether any improvement is statistically defensible
rather than noise, and wall-clock timing for the compute-cost comparison.
"""

import time
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import precision_score, recall_score, f1_score, roc_auc_score, average_precision_score
from scipy.stats import wilcoxon

base = pd.read_parquet("/home/claude/project/data/baseline_features.parquet")
ctx = pd.read_parquet("/home/claude/project/data/graph_context_features.parquet")
y = pd.read_parquet("/home/claude/project/data/labels.parquet")['y']

# Stratified subsample for fast iterative development. Full-data run is
# executed separately in the background (see run_full.log) and used for the
# numbers reported in the manuscript.
SUBSAMPLE_N = 40000
if len(base) > SUBSAMPLE_N:
    rng = np.random.RandomState(42)
    idx_pos = y[y == 1].index.to_numpy()
    idx_neg = y[y == 0].index.to_numpy()
    n_pos = int(SUBSAMPLE_N * (len(idx_pos) / len(y)))
    n_neg = SUBSAMPLE_N - n_pos
    sel = np.concatenate([
        rng.choice(idx_pos, size=min(n_pos, len(idx_pos)), replace=False),
        rng.choice(idx_neg, size=min(n_neg, len(idx_neg)), replace=False),
    ])
    base = base.loc[sel].reset_index(drop=True)
    ctx = ctx.loc[sel].reset_index(drop=True)
    y = y.loc[sel].reset_index(drop=True)

combined = pd.concat([base, ctx], axis=1)

FEATURE_SETS = {
    'baseline_flow_only': base,
    'graph_context_only': ctx,
    'combined': combined,
}

MODELS = {
    'LogReg': Pipeline([
        ('impute', SimpleImputer(strategy='median')),
        ('scale', StandardScaler()),
        ('clf', LogisticRegression(max_iter=2000, class_weight='balanced', random_state=42)),
    ]),
    'RandomForest': Pipeline([
        ('impute', SimpleImputer(strategy='median')),
        ('clf', RandomForestClassifier(n_estimators=100, max_depth=10, n_jobs=-1,
                                        class_weight='balanced', random_state=42)),
    ]),
}

skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
results = []
fold_f1_by_condition = {}  # for significance testing

for model_name, pipe in MODELS.items():
    for cond_name, X in FEATURE_SETS.items():
        fold_metrics = {'precision': [], 'recall': [], 'f1': [], 'roc_auc': [], 'pr_auc': [], 'fit_s': [], 'predict_s': []}
        for fold_i, (tr_idx, te_idx) in enumerate(skf.split(X, y)):
            X_tr, X_te = X.iloc[tr_idx], X.iloc[te_idx]
            y_tr, y_te = y.iloc[tr_idx], y.iloc[te_idx]

            t0 = time.time()
            pipe.fit(X_tr, y_tr)
            fit_s = time.time() - t0

            t0 = time.time()
            y_pred = pipe.predict(X_te)
            y_proba = pipe.predict_proba(X_te)[:, 1]
            predict_s = time.time() - t0

            fold_metrics['precision'].append(precision_score(y_te, y_pred))
            fold_metrics['recall'].append(recall_score(y_te, y_pred))
            fold_metrics['f1'].append(f1_score(y_te, y_pred))
            fold_metrics['roc_auc'].append(roc_auc_score(y_te, y_proba))
            fold_metrics['pr_auc'].append(average_precision_score(y_te, y_proba))
            fold_metrics['fit_s'].append(fit_s)
            fold_metrics['predict_s'].append(predict_s)

        fold_f1_by_condition[(model_name, cond_name)] = fold_metrics['f1']

        row = {'model': model_name, 'feature_set': cond_name, 'n_features': X.shape[1]}
        for k, v in fold_metrics.items():
            row[f'{k}_mean'] = np.mean(v)
            row[f'{k}_std'] = np.std(v)
        results.append(row)
        print(f"{model_name:14s} | {cond_name:20s} | "
              f"F1={row['f1_mean']:.4f}+/-{row['f1_std']:.4f}  "
              f"ROC-AUC={row['roc_auc_mean']:.4f}  "
              f"PR-AUC={row['pr_auc_mean']:.4f}  "
              f"fit={row['fit_s_mean']*1000:.1f}ms")

res_df = pd.DataFrame(results)
res_df.to_csv("/home/claude/project/results/baseline_comparison.csv", index=False)

print("\n--- Significance: combined vs baseline_flow_only (Wilcoxon signed-rank on per-fold F1) ---")
for model_name in MODELS:
    f1_base = fold_f1_by_condition[(model_name, 'baseline_flow_only')]
    f1_comb = fold_f1_by_condition[(model_name, 'combined')]
    if np.allclose(f1_base, f1_comb):
        print(f"{model_name}: F1 scores identical across folds -> no test needed, no difference")
        continue
    stat, p = wilcoxon(f1_comb, f1_base)
    delta = np.mean(f1_comb) - np.mean(f1_base)
    print(f"{model_name}: delta F1 = {delta:+.5f}, Wilcoxon p = {p:.4f}")
