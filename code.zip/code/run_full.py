import time, numpy as np, pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import precision_score, recall_score, f1_score, roc_auc_score, average_precision_score
from scipy.stats import wilcoxon

base = pd.read_parquet("data/baseline_features.parquet")
ctx = pd.read_parquet("data/graph_context_features.parquet")
y = pd.read_parquet("data/labels.parquet")['y']
combined = pd.concat([base, ctx], axis=1)

FEATURE_SETS = {'baseline_flow_only': base, 'graph_context_only': ctx, 'combined': combined}
MODELS = {
    'LogReg': Pipeline([('impute', SimpleImputer(strategy='median')), ('scale', StandardScaler()),
                         ('clf', LogisticRegression(max_iter=2000, class_weight='balanced', random_state=42))]),
    'RandomForest': Pipeline([('impute', SimpleImputer(strategy='median')),
                               ('clf', RandomForestClassifier(n_estimators=150, max_depth=12, n_jobs=-1,
                                                                class_weight='balanced', random_state=42))]),
}
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
results = []
fold_f1 = {}
for model_name, pipe in MODELS.items():
    for cond_name, X in FEATURE_SETS.items():
        m = {'precision': [], 'recall': [], 'f1': [], 'roc_auc': [], 'pr_auc': [], 'fit_s': [], 'predict_s': []}
        for tr_idx, te_idx in skf.split(X, y):
            X_tr, X_te, y_tr, y_te = X.iloc[tr_idx], X.iloc[te_idx], y.iloc[tr_idx], y.iloc[te_idx]
            t0 = time.time(); pipe.fit(X_tr, y_tr); fit_s = time.time() - t0
            t0 = time.time(); pred = pipe.predict(X_te); proba = pipe.predict_proba(X_te)[:, 1]; pred_s = time.time() - t0
            m['precision'].append(precision_score(y_te, pred)); m['recall'].append(recall_score(y_te, pred))
            m['f1'].append(f1_score(y_te, pred)); m['roc_auc'].append(roc_auc_score(y_te, proba))
            m['pr_auc'].append(average_precision_score(y_te, proba)); m['fit_s'].append(fit_s); m['predict_s'].append(pred_s)
        fold_f1[(model_name, cond_name)] = m['f1']
        row = {'model': model_name, 'feature_set': cond_name, 'n_features': X.shape[1]}
        for k, v in m.items():
            row[f'{k}_mean'] = np.mean(v); row[f'{k}_std'] = np.std(v)
        results.append(row)
        print(f"{model_name} | {cond_name} | F1={row['f1_mean']:.4f}+/-{row['f1_std']:.4f} fit={row['fit_s_mean']*1000:.1f}ms", flush=True)

pd.DataFrame(results).to_csv("results/baseline_comparison_FULL.csv", index=False)
print("\n--- Significance (full data, 5-fold, Wilcoxon on per-fold F1) ---")
for model_name in MODELS:
    fb, fc = fold_f1[(model_name,'baseline_flow_only')], fold_f1[(model_name,'combined')]
    if np.allclose(fb, fc):
        print(f"{model_name}: identical, no diff"); continue
    stat, p = wilcoxon(fc, fb)
    print(f"{model_name}: delta F1={np.mean(fc)-np.mean(fb):+.5f}, p={p:.4f}")
print("DONE")
