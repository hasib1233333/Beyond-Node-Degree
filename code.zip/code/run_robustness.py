"""
run_robustness.py

Robustness checks referenced in the manuscript's Robustness and Sensitivity
subsection:
  (1) Threshold sensitivity: does the attack-dominance labeling threshold
      (5%, 10%, 20%) change the window-level separation result, across
      several window sizes?
  (2) Classifier/seed sensitivity: does the flow-level classification result
      hold under a third model family (Gradient Boosting) and multiple
      random seeds?
"""

import sys
import numpy as np
import pandas as pd
from scipy.stats import mannwhitneyu
from sklearn.model_selection import StratifiedKFold
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.metrics import f1_score

from graph_features import load_flows, build_windowed_features


def threshold_sensitivity(csv_path: str):
    df = load_flows(csv_path)
    rows = []
    for win_s in [60, 120, 300]:
        feat = build_windowed_features(df, window_seconds=win_s)
        for thresh in [0.05, 0.10, 0.20]:
            feat['is_attack_window'] = feat['attack_frac'] > thresh
            a = feat.loc[feat['is_attack_window'], 'top1_edge_flow_share'].dropna()
            b = feat.loc[~feat['is_attack_window'], 'top1_edge_flow_share'].dropna()
            if len(a) < 2 or len(b) < 2:
                continue
            stat, p = mannwhitneyu(a, b, alternative='two-sided')
            auc = stat / (len(a) * len(b))
            rows.append({'window_s': win_s, 'threshold': thresh, 'n_attack': len(a), 'n_benign': len(b),
                         'p_value': p, 'separation_auc': max(auc, 1 - auc)})
    return pd.DataFrame(rows)


def classifier_seed_robustness(base_parquet, ctx_parquet, labels_parquet, subsample_n=20000):
    base = pd.read_parquet(base_parquet)
    ctx = pd.read_parquet(ctx_parquet)
    y = pd.read_parquet(labels_parquet)['y']
    combined = pd.concat([base, ctx], axis=1)

    rng = np.random.RandomState(0)
    idx_pos, idx_neg = y[y == 1].index.to_numpy(), y[y == 0].index.to_numpy()
    n_pos = int(subsample_n * (len(idx_pos) / len(y)))
    n_neg = subsample_n - n_pos
    sel = np.concatenate([rng.choice(idx_pos, n_pos, replace=False), rng.choice(idx_neg, n_neg, replace=False)])
    base_s = base.loc[sel].reset_index(drop=True)
    ctx_s = ctx.loc[sel].reset_index(drop=True)
    comb_s = combined.loc[sel].reset_index(drop=True)
    y_s = y.loc[sel].reset_index(drop=True)

    feature_sets = {'baseline_flow_only': base_s, 'graph_context_only': ctx_s, 'combined': comb_s}
    rows = []
    for seed in [0, 1, 2]:
        skf = StratifiedKFold(n_splits=3, shuffle=True, random_state=seed)
        for cond, X in feature_sets.items():
            pipe = Pipeline([('impute', SimpleImputer(strategy='median')),
                              ('clf', GradientBoostingClassifier(n_estimators=60, max_depth=3, random_state=seed))])
            f1s = []
            for tr, te in skf.split(X, y_s):
                pipe.fit(X.iloc[tr], y_s.iloc[tr])
                pred = pipe.predict(X.iloc[te])
                f1s.append(f1_score(y_s.iloc[te], pred))
            rows.append({'seed': seed, 'feature_set': cond, 'f1_mean': np.mean(f1s)})
    return pd.DataFrame(rows)


if __name__ == '__main__':
    csv_path = sys.argv[1] if len(sys.argv) > 1 else \
        "/mnt/user-data/uploads/Friday-WorkingHours-Afternoon-DDos_pcap_ISCX.csv"

    thresh_df = threshold_sensitivity(csv_path)
    thresh_df.to_csv("results/threshold_sensitivity.csv", index=False)
    print(thresh_df.to_string(index=False))

    seed_df = classifier_seed_robustness(
        "data/baseline_features.parquet", "data/graph_context_features.parquet", "data/labels.parquet")
    seed_df.to_csv("results/classifier_seed_robustness.csv", index=False)
    print(seed_df.to_string(index=False))
