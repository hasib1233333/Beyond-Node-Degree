"""
feature_engineering.py — rebuilt for the revision round.
Builds baseline (CICFlowMeter) and graph-context feature matrices per flow,
retaining window_id so folds can be constructed group-aware (Reviewer 1) and
with the near-tautological heaviest-edge indicator made optional (Reviewer 2).
"""

import pandas as pd
import numpy as np
import networkx as nx
from src.graph_features import load_flows, _shannon_entropy

NON_FEATURE_COLS = {
    'Flow ID', 'Source IP', 'Source Port', 'Destination IP', 'Timestamp',
    'Label', 'window_id'
}


def build_flow_level_dataset(path: str, window_seconds: int = 60):
    df = load_flows(path)
    t0 = df['Timestamp'].min()
    df['window_id'] = ((df['Timestamp'] - t0).dt.total_seconds() // window_seconds).astype(int)

    graph_ctx_rows = []
    for wid, wdf in df.groupby('window_id'):
        SG = nx.DiGraph()
        pair_weight = {}
        for _, row in wdf.iterrows():
            key = (row['Source IP'], row['Destination IP'])
            pair_weight[key] = pair_weight.get(key, 0) + 1
        for (s, d), w in pair_weight.items():
            SG.add_edge(s, d, weight=w)

        in_deg = dict(SG.in_degree())
        out_deg = dict(SG.out_degree())
        weights = [d['weight'] for _, _, d in SG.edges(data=True)]
        window_entropy = _shannon_entropy(weights)
        max_w = max(weights) if weights else 0
        top1_share = (max_w / sum(weights)) if weights else 0.0

        dstport_div = wdf.groupby('Source IP')['Destination Port'].nunique().to_dict()
        srcip_div = wdf.groupby('Destination IP')['Source IP'].nunique().to_dict()

        for idx, row in wdf.iterrows():
            s, d = row['Source IP'], row['Destination IP']
            pw = pair_weight.get((s, d), 0)
            graph_ctx_rows.append({
                'idx': idx,
                'window_id': wid,
                'src_out_degree_w': out_deg.get(s, 0),
                'dst_in_degree_w': in_deg.get(d, 0),
                'pair_edge_weight_w': pw,
                'is_top1_edge_w': int(pw == max_w and max_w > 0),  # flagged by Reviewer 2 as near-label
                'window_edge_weight_entropy': window_entropy,
                'window_top1_edge_share': top1_share,
                'window_n_nodes': SG.number_of_nodes(),
                'window_n_edges': SG.number_of_edges(),
                'src_dstport_diversity_w': dstport_div.get(s, 0),
                'dst_srcip_diversity_w': srcip_div.get(d, 0),
            })

    ctx_df = pd.DataFrame(graph_ctx_rows).set_index('idx').sort_index()

    baseline_cols = [c for c in df.columns if c not in NON_FEATURE_COLS]
    baseline_df = df[baseline_cols].copy()
    baseline_df = baseline_df.apply(pd.to_numeric, errors='coerce')
    baseline_df = baseline_df.replace([np.inf, -np.inf], np.nan)

    y = (df['Label'] != 'BENIGN').astype(int)
    y.index = df.index
    window_id_series = df['window_id'].copy()
    window_id_series.index = df.index

    assert len(baseline_df) == len(ctx_df) == len(y)
    return (baseline_df.reset_index(drop=True), ctx_df.reset_index(drop=True),
            y.reset_index(drop=True), window_id_series.reset_index(drop=True),
            df['Label'].reset_index(drop=True))


if __name__ == '__main__':
    base, ctx, y, wid, labels = build_flow_level_dataset("data/Friday-WorkingHours-Afternoon-DDos_pcap_ISCX.csv", window_seconds=60)
    print("baseline:", base.shape, "graph-context:", ctx.shape)
    base.to_parquet("data/baseline_features.parquet")
    ctx.to_parquet("data/graph_context_features.parquet")
    y.to_frame('y').to_parquet("data/labels.parquet")
    wid.to_frame('window_id').to_parquet("data/window_ids.parquet")
    print("saved. window_id range:", wid.min(), wid.max(), "n windows:", wid.nunique())
