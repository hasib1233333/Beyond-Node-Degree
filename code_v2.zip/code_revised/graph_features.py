"""
graph_features.py — rebuilt for the revision round.
Builds time-windowed directed host-communication graphs from labeled flow
records and extracts node-degree and edge-weight structural features.
"""

import pandas as pd
import numpy as np
import networkx as nx
from collections import Counter


def load_flows(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df.columns = [c.strip() for c in df.columns]
    df['Timestamp'] = pd.to_datetime(df['Timestamp'], format='mixed', dayfirst=False, errors='coerce')
    df = df.dropna(subset=['Timestamp'])
    df = df.sort_values('Timestamp').reset_index(drop=True)
    df['Label'] = df['Label'].astype(str).str.strip()
    return df


def _shannon_entropy(counts):
    counts = np.array(counts, dtype=float)
    counts = counts[counts > 0]
    if counts.sum() == 0:
        return 0.0
    p = counts / counts.sum()
    return float(-(p * np.log2(p)).sum())


def build_windowed_features(df: pd.DataFrame, window_seconds: int = 60,
                             src_col: str = 'Source IP', include_top1_indicator: bool = True) -> pd.DataFrame:
    """Slide a fixed-size time window across the flow log and compute one
    structural feature row per window. src_col is parameterized so we can
    swap in synthetic source-IP columns for the collapse-ratio experiment."""
    t0 = df['Timestamp'].min()
    df = df.copy()
    df['window_id'] = ((df['Timestamp'] - t0).dt.total_seconds() // window_seconds).astype(int)

    rows = []
    prev_edges = None
    for wid, wdf in df.groupby('window_id'):
        if len(wdf) == 0:
            continue
        SG = nx.DiGraph()
        pair_weight = {}
        for _, row in wdf.iterrows():
            key = (row[src_col], row['Destination IP'])
            pair_weight[key] = pair_weight.get(key, 0) + 1
        for (s, d), w in pair_weight.items():
            SG.add_edge(s, d, weight=w)

        n_nodes = SG.number_of_nodes()
        in_degs = [d for _, d in SG.in_degree()]
        out_degs = [d for _, d in SG.out_degree()]
        weights = [d['weight'] for _, _, d in SG.edges(data=True)]

        feats = {}
        feats['window_id'] = wid
        feats['window_start'] = t0 + pd.Timedelta(seconds=int(wid) * window_seconds)
        feats['n_nodes'] = n_nodes
        feats['n_flows'] = len(wdf)
        feats['n_unique_edges'] = SG.number_of_edges()
        feats['max_in_degree'] = max(in_degs) if in_degs else 0
        feats['max_out_degree'] = max(out_degs) if out_degs else 0
        feats['in_degree_entropy'] = _shannon_entropy(in_degs)
        feats['max_edge_weight'] = max(weights) if weights else 0
        feats['mean_edge_weight'] = float(np.mean(weights)) if weights else 0.0
        feats['edge_weight_entropy'] = _shannon_entropy(weights)
        feats['top1_edge_flow_share'] = (max(weights) / len(wdf)) if len(wdf) else 0.0
        if include_top1_indicator:
            feats['is_top1_edge_present'] = 1

        curr_edges = set(SG.edges())
        if prev_edges is not None and len(curr_edges) > 0:
            feats['new_edge_ratio'] = len(curr_edges - prev_edges) / len(curr_edges)
        else:
            feats['new_edge_ratio'] = np.nan
        prev_edges = curr_edges

        label_counts = Counter(wdf['Label'])
        n_benign = label_counts.get('BENIGN', 0)
        feats['n_benign'] = n_benign
        feats['n_attack'] = len(wdf) - n_benign
        feats['attack_frac'] = feats['n_attack'] / len(wdf) if len(wdf) else 0.0
        attack_labels = {k: v for k, v in label_counts.items() if k != 'BENIGN'}
        feats['dominant_label'] = max(attack_labels, key=attack_labels.get) if attack_labels else 'BENIGN'

        rows.append(feats)

    return pd.DataFrame(rows).sort_values('window_id').reset_index(drop=True)
