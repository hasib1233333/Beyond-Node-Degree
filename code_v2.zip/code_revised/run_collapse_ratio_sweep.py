"""
run_collapse_ratio_sweep.py

Reviewer 2's central methodological request: the original experiment never
varies k (the true number of distinct attacking hosts collapsed onto one
observed address), so it shows degree fails and edge weight succeeds AT ONE
FIXED COLLAPSE RATIO, not that identity collapse CAUSES the effect.

This script builds a semi-synthetic collapse-ratio sweep on top of the real
attack: we take the real attack flows (real timestamps, real destination =
victim, real per-flow behavioral features unchanged) and vary ONLY how many
distinct synthetic source-IP labels they are spread across, k in
{1, 2, 4, 8, 16, 32, 64, 128, 256, 1024, "all-distinct"}. Benign traffic keeps
its real Source IP throughout -- only the attack's source identity is
synthetically varied, which is exactly the quantity NAT collapse would
determine in reality. For each k we rebuild the windowed host-communication
graph and measure the Mann-Whitney separation AUC for:
  - max in-degree (node-degree family)
  - top1_edge_flow_share (edge-weight family)
between attack-dominant and benign windows.

Prediction under the paper's closed-form argument (Section 4.3): degree
separation should INCREASE as k increases (more visible distinct attacker
nodes -> higher, more unusual victim in-degree), while edge-weight
separation should be highest at LOW k (collapse) and decay as k grows large
(volume spreads thin across many edges, no single edge stands out).
"""

import numpy as np
import pandas as pd
from scipy.stats import mannwhitneyu
from src.graph_features import load_flows, build_windowed_features

df = load_flows("data/Friday-WorkingHours-Afternoon-DDos_pcap_ISCX.csv")
attack_mask_real = df['Label'] == 'DDoS'
n_attack_flows = attack_mask_real.sum()
print(f"Real attack flows to redistribute: {n_attack_flows}")

K_VALUES = [1, 2, 4, 8, 16, 32, 64, 128, 256, 1024, n_attack_flows]  # last = fully distinct, one synthetic IP per flow

rng = np.random.RandomState(42)
rows = []

for k in K_VALUES:
    df_k = df.copy()
    # assign each real attack flow to one of k synthetic source labels (uniform random)
    # benign flows are untouched (real Source IP retained)
    synth_src = df_k['Source IP'].copy()
    attack_idx = df_k.index[attack_mask_real]
    labels = rng.randint(0, k, size=len(attack_idx))
    synth_src.loc[attack_idx] = [f"SynAttacker_{lbl}" for lbl in labels]
    df_k['SynSourceIP'] = synth_src

    feat = build_windowed_features(df_k, window_seconds=60, src_col='SynSourceIP')
    feat['is_attack_window'] = feat['attack_frac'] > 0.1
    a_deg = feat.loc[feat['is_attack_window'], 'max_in_degree'].dropna()
    b_deg = feat.loc[~feat['is_attack_window'], 'max_in_degree'].dropna()
    a_ew = feat.loc[feat['is_attack_window'], 'top1_edge_flow_share'].dropna()
    b_ew = feat.loc[~feat['is_attack_window'], 'top1_edge_flow_share'].dropna()

    def sep_auc(a, b):
        if len(a) < 2 or len(b) < 2:
            return np.nan, np.nan
        stat, p = mannwhitneyu(a, b, alternative='two-sided')
        auc = stat / (len(a) * len(b))
        return max(auc, 1 - auc), p

    deg_auc, deg_p = sep_auc(a_deg, b_deg)
    ew_auc, ew_p = sep_auc(a_ew, b_ew)

    k_label = k if k != n_attack_flows else 'all-distinct'
    rows.append({'k': k_label, 'k_numeric': k, 'degree_sep_auc': deg_auc, 'degree_p': deg_p,
                 'edgeweight_sep_auc': ew_auc, 'edgeweight_p': ew_p,
                 'n_attack_windows': int(feat['is_attack_window'].sum()),
                 'n_benign_windows': int((~feat['is_attack_window']).sum())})
    print(f"k={k_label:>13}  degree_AUC={deg_auc:.3f} (p={deg_p:.2e})   edgeweight_AUC={ew_auc:.3f} (p={ew_p:.2e})")

res = pd.DataFrame(rows)
res.to_csv("results/collapse_ratio_sweep.csv", index=False)
print("\nsaved results/collapse_ratio_sweep.csv")
