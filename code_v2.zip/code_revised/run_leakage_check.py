"""
run_leakage_check.py

Reviewer 1's concern: graph-context features are computed PER WINDOW, so
flows from the same window share nearly-identical window-aggregate feature
values (window_edge_weight_entropy, window_top1_edge_share, window_n_nodes,
window_n_edges are literally constant within a window). The original
evaluation used StratifiedKFold on individual flows, which can place flows
from the same window into both the training and test fold -- letting the
model see a near-duplicate of a test window's aggregate signature during
training. This script re-evaluates under three protocols:

  (1) naive        - StratifiedKFold on flows (the original, potentially leaky protocol)
  (2) group         - GroupKFold grouped by window_id (no window ever split across train/test)
  (3) temporal       - train on the first ~70% of windows chronologically, test on the last ~30%
                        (the strictest test: no test-window information of any kind is available at train time)
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold, GroupKFold
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import f1_score, roc_auc_score, precision_score, recall_score

base = pd.read_parquet("data/baseline_features.parquet")
ctx = pd.read_parquet("data/graph_context_features.parquet")
y = pd.read_parquet("data/labels.parquet")['y']
wid = pd.read_parquet("data/window_ids.parquet")['window_id']
combined = pd.concat([base, ctx], axis=1)

FEATURE_SETS = {'baseline_flow_only': base, 'graph_context_only': ctx, 'combined': combined}


def make_pipe(model_name, seed=42):
    if model_name == 'LogReg':
        return Pipeline([('impute', SimpleImputer(strategy='median')), ('scale', StandardScaler()),
                          ('clf', LogisticRegression(max_iter=2000, class_weight='balanced', random_state=seed))])
    else:
        return Pipeline([('impute', SimpleImputer(strategy='median')),
                          ('clf', RandomForestClassifier(n_estimators=100, max_depth=10, n_jobs=-1,
                                                          class_weight='balanced', random_state=seed))])


def eval_split(X, y, tr_idx, te_idx, model_name):
    pipe = make_pipe(model_name)
    pipe.fit(X.iloc[tr_idx], y.iloc[tr_idx])
    pred = pipe.predict(X.iloc[te_idx])
    proba = pipe.predict_proba(X.iloc[te_idx])[:, 1]
    return {
        'f1': f1_score(y.iloc[te_idx], pred, zero_division=0),
        'precision': precision_score(y.iloc[te_idx], pred, zero_division=0),
        'recall': recall_score(y.iloc[te_idx], pred, zero_division=0),
        'roc_auc': roc_auc_score(y.iloc[te_idx], proba) if len(set(y.iloc[te_idx])) > 1 else float('nan'),
        'n_train': len(tr_idx), 'n_test': len(te_idx),
        'test_attack_frac': y.iloc[te_idx].mean(),
    }


# stratified subsample for tractability, same protocol as the original evaluation
SUBSAMPLE_N = 40000
rng = np.random.RandomState(42)
idx_pos = y[y == 1].index.to_numpy()
idx_neg = y[y == 0].index.to_numpy()
n_pos = int(SUBSAMPLE_N * (len(idx_pos) / len(y)))
n_neg = SUBSAMPLE_N - n_pos
sel = np.sort(np.concatenate([rng.choice(idx_pos, n_pos, replace=False), rng.choice(idx_neg, n_neg, replace=False)]))

base_s = base.loc[sel].reset_index(drop=True)
ctx_s = ctx.loc[sel].reset_index(drop=True)
comb_s = combined.loc[sel].reset_index(drop=True)
y_s = y.loc[sel].reset_index(drop=True)
wid_s = wid.loc[sel].reset_index(drop=True)

FEATURE_SETS_S = {'baseline_flow_only': base_s, 'graph_context_only': ctx_s, 'combined': comb_s}

results = []
for model_name in ['LogReg', 'RandomForest']:
    for cond_name, X in FEATURE_SETS_S.items():

        # --- (1) naive StratifiedKFold on flows ---
        skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
        naive_metrics = [eval_split(X, y_s, tr, te, model_name) for tr, te in skf.split(X, y_s)]
        row = {'protocol': 'naive_stratified', 'model': model_name, 'feature_set': cond_name,
               'f1_mean': np.mean([m['f1'] for m in naive_metrics]),
               'f1_std': np.std([m['f1'] for m in naive_metrics]),
               'roc_auc_mean': np.nanmean([m['roc_auc'] for m in naive_metrics])}
        results.append(row)

        # --- (2) GroupKFold by window_id ---
        gkf = GroupKFold(n_splits=5)
        group_metrics = [eval_split(X, y_s, tr, te, model_name) for tr, te in gkf.split(X, y_s, groups=wid_s)]
        row = {'protocol': 'group_kfold_window', 'model': model_name, 'feature_set': cond_name,
               'f1_mean': np.mean([m['f1'] for m in group_metrics]),
               'f1_std': np.std([m['f1'] for m in group_metrics]),
               'roc_auc_mean': np.nanmean([m['roc_auc'] for m in group_metrics])}
        results.append(row)

        # --- (3) temporal split: train on first 70% of windows, test on last 30% ---
        cutoff = wid_s.quantile(0.70)
        tr_idx = np.where(wid_s <= cutoff)[0]
        te_idx = np.where(wid_s > cutoff)[0]
        if len(set(y_s.iloc[te_idx])) > 1 and len(set(y_s.iloc[tr_idx])) > 1:
            m = eval_split(X, y_s, tr_idx, te_idx, model_name)
            row = {'protocol': 'temporal_70_30', 'model': model_name, 'feature_set': cond_name,
                   'f1_mean': m['f1'], 'f1_std': 0.0, 'roc_auc_mean': m['roc_auc'],
                   'test_attack_frac': m['test_attack_frac'], 'n_test': m['n_test']}
        else:
            row = {'protocol': 'temporal_70_30', 'model': model_name, 'feature_set': cond_name,
                   'f1_mean': float('nan'), 'note': 'test split has only one class'}
        results.append(row)

        print(f"{model_name:14s} {cond_name:20s} naive={naive_metrics and np.mean([m['f1'] for m in naive_metrics]):.4f} "
              f"group={np.mean([m['f1'] for m in group_metrics]):.4f} "
              f"temporal={row.get('f1_mean', float('nan')):.4f}")

res_df = pd.DataFrame(results)
res_df.to_csv("results/leakage_check.csv", index=False)
print("\nsaved results/leakage_check.csv")
print(res_df.to_string(index=False))
